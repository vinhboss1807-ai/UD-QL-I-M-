"""HPU grade management coursework demonstration. Not an official university portal."""
import csv
import io
import json
import os
import secrets
import sqlite3
from datetime import datetime
from functools import wraps
from pathlib import Path
from flask import Flask, Response, abort, flash, g, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

ROOT = Path(__file__).resolve().parent
DB = Path(os.environ.get('GRADE_DB', ROOT / 'data' / 'grades.db'))
app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY') or secrets.token_hex(32)
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='Lax', SESSION_COOKIE_SECURE=os.environ.get('COOKIE_SECURE') == '1')
F_LIMIT = 3.0

def connection():
    if 'db' not in g:
        g.db = sqlite3.connect(DB)
        g.db.row_factory = sqlite3.Row
        g.db.execute('PRAGMA foreign_keys=ON')
    return g.db

@app.teardown_appcontext
def close_connection(exc):
    db = g.pop('db', None)
    if db: db.close()

def init_db():
    DB.parent.mkdir(parents=True, exist_ok=True)
    with app.app_context():
        db=connection()
        db.executescript('''
        CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('admin','teacher','student')), student_id INTEGER, FOREIGN KEY(student_id) REFERENCES students(id));
        CREATE TABLE IF NOT EXISTS students(id INTEGER PRIMARY KEY, code TEXT UNIQUE NOT NULL, name TEXT NOT NULL, class_name TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS courses(id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL, credits INTEGER NOT NULL CHECK(credits>0));
        CREATE TABLE IF NOT EXISTS grades(id INTEGER PRIMARY KEY, student_id INTEGER NOT NULL REFERENCES students(id), course_id INTEGER NOT NULL REFERENCES courses(id), semester TEXT NOT NULL, attendance REAL CHECK(attendance BETWEEN 0 AND 10), midterm REAL CHECK(midterm BETWEEN 0 AND 10), exam REAL CHECK(exam BETWEEN 0 AND 10), UNIQUE(student_id,course_id,semester));
        CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY, username TEXT, action TEXT, detail TEXT, created_at TEXT);
        ''')
        if db.execute('SELECT COUNT(*) FROM students').fetchone()[0] == 0:
            rows=json.loads((ROOT/'data'/'sample.json').read_text(encoding='utf-8'))
            names=list(dict.fromkeys(r['name'] for r in rows))
            for i,name in enumerate(names,1):
                db.execute('INSERT INTO students(code,name,class_name) VALUES(?,?,?)',(f'SV{i:03}',name,'CNTT3K25'))
            for r in rows:
                db.execute('INSERT OR IGNORE INTO courses(name,credits) VALUES(?,?)',(r['course'],r['credits']))
                sid=db.execute('SELECT id FROM students WHERE name=?',(r['name'],)).fetchone()[0]
                cid=db.execute('SELECT id FROM courses WHERE name=?',(r['course'],)).fetchone()[0]
                db.execute('INSERT INTO grades(student_id,course_id,semester,attendance,midterm,exam) VALUES(?,?,?,?,?,?)',(sid,cid,'HK1 2026-2027',r['attendance'],r['midterm'],r['exam']))
        if db.execute('SELECT COUNT(*) FROM users').fetchone()[0] == 0:
            for u,p,role,sid in [('admin','Admin@123','admin',None),('giangvien','Giangvien@123','teacher',None),('sinhvien','Sinhvien@123','student',1)]:
                db.execute('INSERT INTO users(username,password_hash,role,student_id) VALUES(?,?,?,?)',(u,generate_password_hash(p),role,sid))
        db.commit()

def record(action,detail):
    connection().execute('INSERT INTO audit(username,action,detail,created_at) VALUES(?,?,?,?)',(session.get('username'),action,detail,datetime.now().strftime('%Y-%m-%d %H:%M:%S')))

def login_required(fn):
    @wraps(fn)
    def wrapped(*a,**kw):
        if 'uid' not in session:return redirect(url_for('login'))
        return fn(*a,**kw)
    return wrapped

def roles(*allowed):
    def deco(fn):
        @wraps(fn)
        @login_required
        def wrapped(*a,**kw):
            if session.get('role') not in allowed:abort(403)
            return fn(*a,**kw)
        return wrapped
    return deco

@app.before_request
def csrf_guard():
    if request.method == 'POST':
        if not secrets.compare_digest(session.get('csrf',''),request.form.get('csrf','')):abort(400,'Biểu mẫu không hợp lệ. Vui lòng tải lại trang.')

@app.context_processor
def global_data():
    return {'csrf':session.get('csrf',''),'role':session.get('role'),'username':session.get('username')}

def grade_value(row):
    if any(row[k] is None for k in ('attendance','midterm','exam')):return None
    return row['attendance']*.2 + row['midterm']*.3 + row['exam']*.5

def grade_letter(v):
    if v is None:return '—'
    return 'F' if v < 3 else 'D' if v < 5 else 'C' if v < 7 else 'B' if v < 9 else 'A'

def grade_rows(search='', semester='', only_f=False):
    sql='''SELECT g.*,s.code,s.name,s.class_name,c.name AS course,c.credits FROM grades g JOIN students s ON g.student_id=s.id JOIN courses c ON g.course_id=c.id WHERE 1=1'''
    vals=[]
    if session.get('role')=='student':sql+=' AND s.id=?';vals.append(session['student_id'])
    if search:sql+=' AND (s.name LIKE ? OR s.code LIKE ? OR c.name LIKE ?)';vals.extend(['%'+search+'%']*3)
    if semester:sql+=' AND g.semester=?';vals.append(semester)
    sql+=' ORDER BY s.name,c.name'
    out=[]
    for row in connection().execute(sql,vals).fetchall():
        x=dict(row);x['total']=grade_value(x);x['letter']=grade_letter(x['total'])
        if not only_f or (x['total'] is not None and x['total'] < F_LIMIT):out.append(x)
    return out

def semester_options():return [r[0] for r in connection().execute('SELECT DISTINCT semester FROM grades ORDER BY semester DESC')]

@app.route('/login',methods=['GET','POST'])
def login():
    if request.method=='POST':
        u=connection().execute('SELECT * FROM users WHERE username=?',(request.form.get('username',''),)).fetchone()
        if u and check_password_hash(u['password_hash'],request.form.get('password','')):
            session.clear();session.update(uid=u['id'],username=u['username'],role=u['role'],student_id=u['student_id'],csrf=secrets.token_hex(24))
            return redirect(url_for('dashboard'))
        flash('Tên đăng nhập hoặc mật khẩu không đúng.','error')
    session.setdefault('csrf',secrets.token_hex(24))
    return render_template('login.html')

@app.route('/logout',methods=['POST'])
@login_required
def logout():session.clear();return redirect(url_for('login'))

@app.route('/')
@login_required
def dashboard():
    rows=grade_rows(semester=request.args.get('semester',''))
    student_count=len({r['student_id'] for r in rows});failed=[r for r in rows if r['letter']=='F']
    passed=[r for r in rows if r['total'] is not None]
    avg=(sum(r['total']*r['credits'] for r in passed)/sum(r['credits'] for r in passed)) if passed else 0
    dist={k:sum(1 for r in rows if r['letter']==k) for k in 'ABCDF'}
    return render_template('dashboard.html',students=student_count,courses=len({r['course_id'] for r in rows}),failed=failed,avg=avg,dist=dist,semesters=semester_options(),semester=request.args.get('semester',''),rows=rows)

@app.route('/grades')
@login_required
def grades():
    return render_template('grades.html',rows=grade_rows(request.args.get('q','').strip(),request.args.get('semester',''),request.args.get('f')=='1'),q=request.args.get('q',''),semester=request.args.get('semester',''),semesters=semester_options(),only_f=request.args.get('f')=='1')

@app.route('/grades/add',methods=['GET','POST'])
@roles('admin','teacher')
def add_grade():
    if request.method=='POST':
        try:
            sid=int(request.form['student_id']);cid=int(request.form['course_id']);semester=request.form['semester'].strip()
            if not semester or len(semester)>40:raise ValueError('Học kỳ không hợp lệ')
            values=[parse_score(request.form.get(k,'')) for k in ('attendance','midterm','exam')]
            connection().execute('INSERT INTO grades(student_id,course_id,semester,attendance,midterm,exam) VALUES(?,?,?,?,?,?)',(sid,cid,semester,*values))
            record('Thêm điểm',f'SV id {sid}; học phần id {cid}; {semester}')
            connection().commit();flash('Đã thêm kết quả học phần.','success');return redirect(url_for('grades'))
        except (ValueError,sqlite3.IntegrityError) as e:connection().rollback();flash('Không thể lưu: '+str(e),'error')
    return render_template('grade_form.html',item=None,students=connection().execute('SELECT * FROM students ORDER BY name'),courses=connection().execute('SELECT * FROM courses ORDER BY name'))

def parse_score(s):
    if s is None or s.strip()=='':return None
    v=float(s.replace(',','.'))
    if not (0<=v<=10):raise ValueError('Điểm phải nằm trong khoảng 0–10')
    return v

@app.route('/grades/<int:gid>/edit',methods=['GET','POST'])
@roles('admin','teacher')
def edit_grade(gid):
    item=connection().execute('SELECT g.*,s.name,c.name AS course FROM grades g JOIN students s ON g.student_id=s.id JOIN courses c ON g.course_id=c.id WHERE g.id=?',(gid,)).fetchone()
    if not item:abort(404)
    if request.method=='POST':
        try:
            vals=[parse_score(request.form.get(k,'')) for k in ('attendance','midterm','exam')]
            before=[item[k] for k in ('attendance','midterm','exam')]
            connection().execute('UPDATE grades SET attendance=?,midterm=?,exam=? WHERE id=?',(*vals,gid))
            record('Sửa điểm',f'Bản ghi {gid}: {before} => {vals}')
            connection().commit();flash('Đã cập nhật điểm và ghi nhật ký.','success');return redirect(url_for('grades'))
        except ValueError as e:connection().rollback();flash(str(e),'error')
    return render_template('grade_form.html',item=item)

@app.route('/students',methods=['GET','POST'])
@roles('admin','teacher')
def students():
    if request.method=='POST':
        if session['role']!='admin':abort(403)
        code=request.form.get('code','').strip();name=request.form.get('name','').strip();cl=request.form.get('class_name','').strip()
        if not all((code,name,cl)) or max(map(len,(code,name,cl)))>100:flash('Thông tin không hợp lệ.','error')
        else:
            try:
                connection().execute('INSERT INTO students(code,name,class_name) VALUES(?,?,?)',(code,name,cl));record('Thêm sinh viên',code+' '+name);connection().commit();flash('Đã thêm sinh viên.','success')
            except sqlite3.IntegrityError:connection().rollback();flash('Mã sinh viên đã tồn tại.','error')
        return redirect(url_for('students'))
    return render_template('students.html',students=connection().execute('SELECT * FROM students ORDER BY name').fetchall())

@app.route('/report')
@login_required
def report():
    rows=grade_rows(semester=request.args.get('semester',''))
    groups={}
    for r in rows:
        k=(r['student_id'],r['semester'])
        if k not in groups:groups[k]={'code':r['code'],'name':r['name'],'semester':r['semester'],'class_name':r['class_name'],'weighted':0,'credits':0,'f':0,'missing':0}
        if r['total'] is None:groups[k]['missing']+=1
        else:
            groups[k]['weighted']+=r['total']*r['credits'];groups[k]['credits']+=r['credits'];groups[k]['f']+=int(r['total']<F_LIMIT)
    for x in groups.values():x['average']=x['weighted']/x['credits'] if x['credits'] else None
    return render_template('report.html',records=list(groups.values()),semester=request.args.get('semester',''),semesters=semester_options())

@app.route('/export')
@login_required
def export():
    rows=grade_rows(semester=request.args.get('semester',''),only_f=request.args.get('f')=='1')
    output=io.StringIO();output.write('\ufeff');writer=csv.writer(output)
    writer.writerow(['Mã SV','Họ tên','Lớp','Học kỳ','Học phần','Tín chỉ','Chuyên cần','Kiểm tra','Thi','Điểm học phần','Điểm chữ'])
    for r in rows:writer.writerow([r['code'],r['name'],r['class_name'],r['semester'],r['course'],r['credits'],r['attendance'],r['midterm'],r['exam'],round(r['total'],2) if r['total'] is not None else '',r['letter']])
    return Response(output.getvalue(),mimetype='text/csv; charset=utf-8',headers={'Content-Disposition':'attachment; filename="bang_diem.csv"'})

@app.route('/audit')
@roles('admin')
def audit():return render_template('audit.html',logs=connection().execute('SELECT * FROM audit ORDER BY id DESC LIMIT 100').fetchall())

@app.route('/password',methods=['GET','POST'])
@login_required
def password():
    if request.method=='POST':
        db=connection();u=db.execute('SELECT * FROM users WHERE id=?',(session['uid'],)).fetchone()
        old=request.form.get('old','');new=request.form.get('new','')
        if not check_password_hash(u['password_hash'],old):flash('Mật khẩu hiện tại không đúng.','error')
        elif len(new)<10:flash('Mật khẩu mới cần ít nhất 10 ký tự.','error')
        else:
            db.execute('UPDATE users SET password_hash=? WHERE id=?',(generate_password_hash(new),session['uid']))
            record('Đổi mật khẩu','Tài khoản tự đổi mật khẩu');db.commit();flash('Đổi mật khẩu thành công.','success');return redirect(url_for('dashboard'))
    return render_template('password.html')

@app.errorhandler(403)
def forbidden(err):return 'Bạn không có quyền truy cập chức năng này.',403

init_db()
if __name__=='__main__':
    app.run(host='127.0.0.1',port=int(os.environ.get('PORT',5000)),debug=False)
