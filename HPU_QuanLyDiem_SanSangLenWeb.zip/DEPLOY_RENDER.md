# Đưa website lên Render (bản trình diễn công khai)

1. Tải các tệp **bên trong** thư mục HPU_QuanLyDiem lên thư mục gốc GitHub repo, gồm `app.py`, `requirements.txt`, `templates`, `static`, `data`. Không tải `.venv` hay `.db`.
2. Trên https://dashboard.render.com chọn **New > Web Service**, liên kết GitHub repo.
3. Chọn Runtime/Language **Python 3**, Build Command: `pip install -r requirements.txt`, Start Command: `gunicorn --bind 0.0.0.0:$PORT app:app`, Instance Type **Free** nếu có.
4. Thêm biến môi trường `SECRET_KEY` là chuỗi ngẫu nhiên dài (không lưu trong GitHub); `COOKIE_SECURE=1`.
5. Deploy và mở URL `https://<ten>.onrender.com`.

**Cảnh báo**: Bản này chỉ dùng dữ liệu/tài khoản minh họa. Mật khẩu demo nằm trong README và không an toàn khi đưa công khai. Hãy đổi mật khẩu ngay; tuy nhiên ứng dụng chưa có rate limiting và các biện pháp bảo vệ cần thiết cho hệ thống thật. SQLite trên Render Free **mất các thay đổi khi dịch vụ ngủ, khởi động lại hoặc redeploy**, và tài khoản demo có thể được khôi phục về mặc định. KHÔNG đưa dữ liệu sinh viên thật hoặc dùng cho vận hành trường học.
