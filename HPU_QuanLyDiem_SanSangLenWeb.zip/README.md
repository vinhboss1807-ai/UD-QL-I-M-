# Ứng dụng quản lý điểm sinh viên — ĐH Hải Phòng (bản minh họa)

Đây là ứng dụng **demo phục vụ bài tập lớn INF722**, không phải website chính thức của Trường Đại học Hải Phòng. Dữ liệu lấy từ bảng Excel mẫu (6 sinh viên, 5 học phần, 30 kết quả). Mã sinh viên `SV001`–`SV006` được tạo cho demo vì tệp Excel chỉ có họ tên và lớp.

## Chạy trên Windows (Python 3.10+)

1. Giải nén ZIP vào thư mục dễ tìm (ví dụ Desktop).
2. Mở thư mục `HPU_QuanLyDiem`, bấm thanh địa chỉ File Explorer, gõ `cmd`, Enter.
3. Chạy các lệnh sau:

```bat
py -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
python app.py
```

4. Mở trình duyệt tại **http://127.0.0.1:5000**.
5. Dừng bằng **Ctrl + C** trong cửa sổ CMD.

Nếu Windows không nhận `py`, thử `python`. Nếu port 5000 bận, chạy `set PORT=5001` rồi `python app.py`, mở cổng 5001.

## Tài khoản demo

| Vai trò | Username | Password |
|---|---|---|
| Quản trị | `admin` | `Admin@123` |
| Giảng viên | `giangvien` | `Giangvien@123` |
| Sinh viên | `sinhvien` | `Sinhvien@123` |

Sinh viên demo liên kết với bản ghi `SV001` và chỉ nhìn thấy bảng điểm của mình. Hãy đổi mật khẩu khi chạy để trình diễn.

## Chức năng hiện có

- Đăng nhập, đăng xuất, đổi mật khẩu, phân quyền trên máy chủ.
- Dashboard thống kê số sinh viên, môn học, điểm TB có trọng số, số lượt F và biểu đồ phân bố điểm chữ.
- Tra cứu theo họ tên/mã SV/học phần, lọc học kỳ và học phần F, xuất bảng điểm CSV.
- Thêm sinh viên (admin); thêm/sửa điểm thành phần (admin/giảng viên); lưu nhật ký thay đổi điểm.
- Báo cáo điểm trung bình tín chỉ theo **từng sinh viên – học kỳ**, kể cả F; chú thích trung bình tạm thời nếu thiếu điểm.
- Lưu dữ liệu vào SQLite (`data/grades.db`) và duy trì qua khởi động lại.

## Quy tắc từ tài liệu mẫu

Điểm HP = 0,2 × chuyên cần + 0,3 × kiểm tra + 0,5 × thi. F nếu điểm HP **< 3,00 (chưa làm tròn)**; D từ 3 đến <5; C từ 5 đến <7; B từ 7 đến <9; A từ 9 đến 10. Điểm trống không được quy thành 0. Trung bình theo tín chỉ = tổng(điểm HP × tín chỉ)/tổng tín chỉ đối với các môn đã đủ điểm.

**Lưu ý:** Báo cáo có nhắc đến ngưỡng cũ 2,50 và cách phân loại B trong khoảng 8–9 còn cần thống nhất. Bản demo này chọn quy tắc `<3,00` và `B <9,00` theo phần quy tắc cập nhật của tài liệu, **không đại diện quy chế chính thức**.

## Giới hạn và an toàn

- Chỉ chạy localhost để thử nghiệm; **không đưa nguyên bản lên Internet** hoặc dùng dữ liệu sinh viên thật.
- Tài khoản và mật khẩu demo là công khai trong README; `SECRET_KEY` mặc định thay đổi mỗi lần chạy, vì vậy khi đưa lên server riêng phải cấu hình cố định và ngẫu nhiên.
- Chưa có quy trình duyệt/khóa công bố điểm, quản lý giảng viên/lớp học phần chi tiết, khôi phục mật khẩu, xác thực nhiều yếu tố, rate-limit, sao lưu tự động hay các yêu cầu bảo mật cho triển khai thực tế.
- Tên lớp và học kỳ là dữ liệu demo. Trước khi triển khai thực, phải xác minh quy chế đào tạo và thiết kế bảo mật/kiểm thử đầy đủ.

## Cấu trúc

- `app.py`: Flask routes, SQLite, nghiệp vụ tính điểm, phân quyền.
- `templates/`: giao diện HTML.
- `static/style.css`: giao diện responsive.
- `data/sample.json`: 30 kết quả mẫu được chuyển từ bảng Excel người dùng cung cấp.
- `test_app.py`: kiểm thử nghiệp vụ cơ bản.

Để **đặt lại dữ liệu mẫu**, tắt chương trình rồi xóa `data/grades.db`, chạy lại `python app.py`. Việc này sẽ xóa mọi thay đổi đã nhập.


## Đưa bản demo lên web

Xem `DEPLOY_RENDER.md` để triển khai lên Render từ GitHub.
