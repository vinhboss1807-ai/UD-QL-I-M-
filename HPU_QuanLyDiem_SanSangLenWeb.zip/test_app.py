import unittest
from app import app, grade_letter, grade_value, grade_rows

class GradeTests(unittest.TestCase):
    def test_grade_boundaries(self):
        self.assertEqual(grade_letter(2.99),'F')
        self.assertEqual(grade_letter(3),'D')
        self.assertEqual(grade_letter(5),'C')
        self.assertEqual(grade_letter(7),'B')
        self.assertEqual(grade_letter(8.85),'B')
        self.assertEqual(grade_letter(9),'A')
    def test_component_scores(self):
        self.assertAlmostEqual(grade_value({'attendance':6.6,'midterm':6.8,'exam':8.98}),7.85)
        self.assertIsNone(grade_value({'attendance':None,'midterm':6,'exam':7}))
    def test_login_and_access(self):
        client=app.test_client()
        with client.session_transaction() as s:s['csrf']='testing'
        response=client.post('/login',data={'csrf':'testing','username':'sinhvien','password':'Sinhvien@123'},follow_redirects=True)
        self.assertEqual(response.status_code,200)
        self.assertEqual(client.get('/students').status_code,403)
        self.assertEqual(client.get('/grades/add').status_code,403)
        self.assertIn('Bảng điểm',client.get('/grades').get_data(as_text=True))
    def test_demo_f_count(self):
        with app.test_request_context('/'):
            from flask import session
            session['role']='admin'
            rows=grade_rows()
            self.assertEqual(len(rows),30)
            self.assertEqual(sum(r['letter']=='F' for r in rows),4)

if __name__=='__main__':unittest.main()
